var struct_p_w_m_c_o_n_f__t =
[
    [ "freewheel", "struct_p_w_m_c_o_n_f__t.html#a30952f3b95f214b64252bb87bdbe12fd", null ],
    [ "pwm_ampl", "struct_p_w_m_c_o_n_f__t.html#af9f3f4abae3ec5f222194a91c5a2bb81", null ],
    [ "pwm_autoscale", "struct_p_w_m_c_o_n_f__t.html#a4e31e46785c24ed8b2c007b832b68ed5", null ],
    [ "pwm_freq", "struct_p_w_m_c_o_n_f__t.html#a00985bf88d4b1e4ff19da4989bab9596", null ],
    [ "pwm_grad", "struct_p_w_m_c_o_n_f__t.html#adba741e1393d963652d10fbf28f9dfc0", null ],
    [ "pwm_symmetric", "struct_p_w_m_c_o_n_f__t.html#a240007131a0e219d0c78a8456b0c3cd2", null ],
    [ "sr", "struct_p_w_m_c_o_n_f__t.html#a550d2fbdf52fac7edd199b0cda146e08", null ]
];