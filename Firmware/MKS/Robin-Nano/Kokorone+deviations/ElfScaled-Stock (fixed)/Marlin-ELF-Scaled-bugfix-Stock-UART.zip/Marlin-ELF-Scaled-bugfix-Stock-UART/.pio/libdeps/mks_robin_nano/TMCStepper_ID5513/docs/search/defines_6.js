var searchData=
[
  ['writemosi_5fh_1150',['writeMOSI_H',['../_t_m_c__platforms_8h.html#aae28defc4c391982df05cb414663956e',1,'TMC_platforms.h']]],
  ['writemosi_5fl_1151',['writeMOSI_L',['../_t_m_c__platforms_8h.html#a00ddb733cb8aae0fc31326e4163cc638',1,'TMC_platforms.h']]],
  ['writesck_5fh_1152',['writeSCK_H',['../_t_m_c__platforms_8h.html#a889f92ec583d898b35cf083e12ef371a',1,'TMC_platforms.h']]],
  ['writesck_5fl_1153',['writeSCK_L',['../_t_m_c__platforms_8h.html#a595d617b4d8e35526e7c38367baf637c',1,'TMC_platforms.h']]]
];
