var searchData=
[
  ['neg_5fedge_744',['neg_edge',['../class_t_m_c5130_stepper.html#a1779021fd601b238570769030053b8ec',1,'TMC5130Stepper::neg_edge(bool B)'],['../class_t_m_c5130_stepper.html#a6116f9f5714d5131872647944b9f76d6',1,'TMC5130Stepper::neg_edge()']]]
];
