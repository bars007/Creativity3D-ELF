var searchData=
[
  ['sg_5fresult_5ft_529',['SG_RESULT_t',['../struct_t_m_c2209__n_1_1_s_g___r_e_s_u_l_t__t.html',1,'TMC2209_n']]],
  ['sgcsconf_5ft_530',['SGCSCONF_t',['../struct_s_g_c_s_c_o_n_f__t.html',1,'']]],
  ['sgthrs_5ft_531',['SGTHRS_t',['../struct_t_m_c2209__n_1_1_s_g_t_h_r_s__t.html',1,'TMC2209_n']]],
  ['short_5fconf_5ft_532',['SHORT_CONF_t',['../struct_s_h_o_r_t___c_o_n_f__t.html',1,'']]],
  ['slaveconf_5ft_533',['SLAVECONF_t',['../struct_s_l_a_v_e_c_o_n_f__t.html',1,'']]],
  ['smarten_5ft_534',['SMARTEN_t',['../struct_s_m_a_r_t_e_n__t.html',1,'']]],
  ['sswitch_535',['SSwitch',['../class_s_switch.html',1,'']]],
  ['sw_5fmode_5ft_536',['SW_MODE_t',['../struct_s_w___m_o_d_e__t.html',1,'']]],
  ['sw_5fspiclass_537',['SW_SPIClass',['../class_s_w___s_p_i_class.html',1,'']]]
];
