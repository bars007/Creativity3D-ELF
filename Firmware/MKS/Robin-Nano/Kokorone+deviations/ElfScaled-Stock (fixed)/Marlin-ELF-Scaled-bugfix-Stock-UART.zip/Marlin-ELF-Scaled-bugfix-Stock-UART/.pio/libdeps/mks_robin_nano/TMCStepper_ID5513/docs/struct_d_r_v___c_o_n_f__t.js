var struct_d_r_v___c_o_n_f__t =
[
    [ "bbmclks", "struct_d_r_v___c_o_n_f__t.html#a6b889df9ac94ad6a209f68cf653b9070", null ],
    [ "bbmtime", "struct_d_r_v___c_o_n_f__t.html#a24185afa79f5ea73429414915be22def", null ],
    [ "drvstrength", "struct_d_r_v___c_o_n_f__t.html#a70e3f1e39184006d9b05fc00bfde5fde", null ],
    [ "filt_isense", "struct_d_r_v___c_o_n_f__t.html#a1118c751f75228252367a11c3e6ab050", null ],
    [ "otselect", "struct_d_r_v___c_o_n_f__t.html#acef570a0d8fdd8b5ae59f18478d755b2", null ],
    [ "sr", "struct_d_r_v___c_o_n_f__t.html#a4d4c5ad2ff02b9a1a628c6cf2e5c692f", null ]
];