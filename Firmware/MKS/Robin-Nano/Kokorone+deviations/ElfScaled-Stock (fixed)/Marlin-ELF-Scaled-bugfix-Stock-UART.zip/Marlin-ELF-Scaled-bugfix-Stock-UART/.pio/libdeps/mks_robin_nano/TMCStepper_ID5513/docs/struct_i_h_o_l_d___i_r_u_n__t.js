var struct_i_h_o_l_d___i_r_u_n__t =
[
    [ "ihold", "struct_i_h_o_l_d___i_r_u_n__t.html#aecfae91788fb6ee976db810c393e1660", null ],
    [ "iholddelay", "struct_i_h_o_l_d___i_r_u_n__t.html#a993170d8e957741327f570f1d8fcda0b", null ],
    [ "irun", "struct_i_h_o_l_d___i_r_u_n__t.html#ac04d234427a7011275ff898e0614162a", null ],
    [ "sr", "struct_i_h_o_l_d___i_r_u_n__t.html#ac2de0aac8f65b0eb72f0b552e7620e4d", null ]
];