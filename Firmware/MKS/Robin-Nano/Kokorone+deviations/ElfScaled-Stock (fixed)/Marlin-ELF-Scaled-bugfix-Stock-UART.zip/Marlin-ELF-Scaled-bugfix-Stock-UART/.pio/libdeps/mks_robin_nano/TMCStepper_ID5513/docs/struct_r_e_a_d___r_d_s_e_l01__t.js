var struct_r_e_a_d___r_d_s_e_l01__t =
[
    [ "__pad0__", "struct_r_e_a_d___r_d_s_e_l01__t.html#ad6a2f12bdd538e363db1c015ad67ea96", null ],
    [ "ola", "struct_r_e_a_d___r_d_s_e_l01__t.html#a8baf6d96987849df81038717650660d7", null ],
    [ "olb", "struct_r_e_a_d___r_d_s_e_l01__t.html#a68f92ee0ddeed0b6045945847214f30b", null ],
    [ "ot", "struct_r_e_a_d___r_d_s_e_l01__t.html#adc37ba7811d112382761c8c2434bc1cd", null ],
    [ "otpw", "struct_r_e_a_d___r_d_s_e_l01__t.html#ab06c0d12112131ec71b69250626e4c01", null ],
    [ "s2ga", "struct_r_e_a_d___r_d_s_e_l01__t.html#a47073ed3b95fcca108d647fa5ac57e24", null ],
    [ "s2gb", "struct_r_e_a_d___r_d_s_e_l01__t.html#a30c259b25fc2058596d651d92527efff", null ],
    [ "sg_result", "struct_r_e_a_d___r_d_s_e_l01__t.html#a1c7d35a4006b70b55637bc09e063201b", null ],
    [ "sg_value", "struct_r_e_a_d___r_d_s_e_l01__t.html#aef3df7c2fbd7d924179bb29341270fc5", null ],
    [ "sr", "struct_r_e_a_d___r_d_s_e_l01__t.html#a00ebf9bacc3c18c97015e6faff650ece", null ],
    [ "stst", "struct_r_e_a_d___r_d_s_e_l01__t.html#aa09d0f359f502e757c286ec12dd0c717", null ]
];