# STL Files concerning the printer.

These are printable files containing things regarding the hotend.

* V6 (and clone) mount provided by Brad Hilker

These were found on the facebook group of the printer.